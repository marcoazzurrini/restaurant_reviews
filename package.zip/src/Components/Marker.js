import React from "react";
import Placeholder from "../img/placeholder.png";
export default function Marker(props) {
  return <img src={Placeholder} alt="placeholder" />;
}
